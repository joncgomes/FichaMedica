import React from 'react';

import { Container } from './styles';

export default function Body() {
  function handleSubmit(){

  }

  return (
    <Container>
      <div className="container">

        <div className="content">
          <p>
          <p>
            <center>
            <strong>Formalário do Paciente</strong>
            </center>
          </p>
          </p>
          <p>
          <strong>Ficha Inicial</strong>
          </p>

          <form onSubmit={handleSubmit}>
            <label>NOME:</label>
            <input
              id="nome"
              placeholder="Informe seu Nome"          
            />
            <label>IDADE:</label>
            <input
              id="idade"
              placeholder="Informe a Idade"          
            />
            <label>REGISTRO:</label>
            <input
              id="registro"
              placeholder="Informe o Registro"          
            />
            <label>DATA:</label>
            <input
              id="data"
              placeholder="Informe a Data"          
            />
            <label>DIAGNÓSTICO:</label>
            <input
              id="diagnostico"
              placeholder="Informe o Diagnóstico"          
            />
            <label>PROCEDIMENTO PROPOSTO:</label>
            <input
              id="procedimento_proposto"
              placeholder="Informe o Procedimento"          
            />

            <form action="#" method="post">
		          <fieldset>
			          <legend>Sexo</legend>
			            <label for="m"><input type="radio" name="sexo" id="m" value="m" /> Masculino</label>
			            <label for="f"><input type="radio" name="sexo" id="f" value="f" /> Feminino</label>
	          	</fieldset>
	          </form>

            <p>
            <br></br>
            <h2>ANTECEDENTES PESSOAIS</h2>
            <br></br>
            <br></br>
            </p>
          



            <form action="#" method="post">
		          <fieldset>
			          <legend>HAS (Hipertensao Arterial)</legend>
                <label><input type="radio" class="radio" name="HipertensaoSim" id="HipertensaoSim" value="Sim"/>Sim</label>           
                <label><input type="radio" class="radio" name="HipertensaoNao" id="HipertensaoNao" value="Nao"/>Não</label>  
	          	</fieldset>
	          </form>


            <div class="form-group">
            <label>HAS (Hipertensao Arterial)
            <p>
            <input type="radio" class="radio" name="HipertensaoSim" id="HipertensaoSim" value="Sim"/>Sim
           
            <input type="radio" class="radio" name="HipertensaoNao" id="HipertensaoNao" value="Nao"/>Não
            </p>
            </label>
            </div>

            <div class="form-group">
            <label>HISTÓRIA DE ICC</label>
            <input type="radio" name="iccSim" id="iccSim" value="Sim"/>Sim
            <input type="radio" name="iccNao" id="iccSim" value="Nao"/>Não
            </div>

            <div class="form-group">
            <label>HISTÓRIA DE CARDIOPATIA ISQUÊMICA/ANGINA</label>
            <input type="radio" name="cardiopatiaSim" id="cardiopatiaSim" value="Sim"/>Sim
            <input type="radio" name="cardiopatiaNao" id="cardiopatiaNao" value="Nao"/>Não
            <label>Histórico de Cardiopatia Isquêmica/Angina:</label>
            <input
              id="cardiopatia_angina"
              placeholder="Digite o Histório de Cardiopatia Isquêmica/Angina"          
            />
            </div>

            <div class="form-group">
            <label>DM</label>
            <input type="radio" name="dmSim" id="dmSim" value="Sim"/>Sim
            <input type="radio" name="dmNao" id="dmNao" value="Nao"/>Não
            <label>INSULINO-REQUERENTE</label>
            <input type="radio" name="insulinoSim" id="insulinoSim" value="Sim"/>Sim
            <input type="radio" name="insulinoNao" id="insulinoNao" value="Nao"/>Sim
            </div>

            <div class="form-group">
            <label>ARRITIMIA CARDÍACA</label>
            <input type="radio" name="arritimiaSim" id="arritimiaSim" value="Sim"/>Sim
            <input type="radio" name="arritimiaNao" id="arritimiaNao" value="Nao"/>Não
            <label>Histórico de Arritimia Cardíaca:</label>
            <input
              id="arritimiaSim"
              placeholder="Digite o Histório de Arritimia Cardíaca"          
            />
            </div>

            <div class="form-group">
            <label>CONDIÇÃO CARDÍACA ATIVA</label>
            <input type="radio" name="condicao_cardiaca_ativaSim" id="condicao_cardiaca_ativaSimSim" value="Sim"/>Sim
            <input type="radio" name="condicao_cardiaca_ativaNao" id="condicao_cardiaca_ativaSimNao" value="Nao"/>Não
            <label>Histórico de Condição Cardíaca Ativa:</label>
            <input
              id="condicao_cardiaca_ativaSimSim"
              placeholder="Digite o Histório de Condição Cardíaca Ativa"          
            />
            </div>

            <div class="form-group">
            <label>ASMA</label>
            <input type="radio" name="asmaSim" id="asmaSim" value="Sim"/>Sim
            <input type="radio" name="asmaNao" id="asmaNao" value="Nao"/>Não
            <label>Histórico de ASMA:</label>
            <input
              id="asmaSim"
              placeholder="Digite o Histório de ASMA"          
            />
            </div>

            <div class="form-group">
            <label>INFECÇÃO RESPIRATÓRIA MENOR QUE 01 MÊS (FEBRE + ANTIBIÓTICOS)</label>
            <input type="radio" name="asmaSim" id="asmaSim" value="Sim"/>Sim
            <input type="radio" name="asmaNao" id="asmaNao" value="Nao"/>Não
            <label>Histórico de ASMA:</label>
            <input
              id="asmaSim"
              placeholder="Digite o Histório de ASMA"          
            />
            </div>

            <div class="form-group">
            <label>RONCO RUIDOSO </label>
            <input type="radio" name="ronco_ruidosoSim" id="ronco_ruidosoSim" value="Sim"/>Sim
            <input type="radio" name="ronco_ruidosoNao" id="ronco_ruidosoNao" value="Nao"/>Não
            </div>

            <div class="form-group">
            <label>APNÉIA </label>
            <input type="radio" name="apneiaSim" id="apneiaSim" value="Sim"/>Sim
            <input type="radio" name="apneiaNao" id="apneiaNao" value="Nao"/>Não
            </div>

            <div class="form-group">
            <label>CANSAÇO DIURNO </label>
            <input type="radio" name="cansaco_diurno" id="cansaco_diurno" value="Sim"/>Sim
            <input type="radio" name="cansaco_diurno" id="cansaco_diurno" value="Nao"/>Não
            </div>

            <div class="form-group">
            <label>TIREOIDOPATIA </label>
            <input type="radio" name="tireoidopatiaSim" id="tireoidopatiaSim" value="Sim"/>Sim
            <input type="radio" name="tireoidopatiaNao" id="tireoidopatiaNao" value="Nao"/>Não
            <label>Histórico de TIREOIDOPATIA:</label>
            <input
              id="tireoidopatiaSim"
              placeholder="Digite o Histório de TIREOIDOPATIA"          
            />
            </div>

            <div class="form-group">
            <label>IRC</label>
            <input type="radio" name="ircSim" id="ircSim" value="Sim"/>Sim
            <input type="radio" name="ircNao" id="ircNao" value="Nao"/>Não
            <label>DIALÍTICO</label>
            <input type="radio" name="dialiticoSim" id="dialiticoSim" value="Nao"/>Não
            <input type="radio" name="dialiticoNao" id="idialiticoNao" value="Nao"/>Não
            </div>
          
            <div class="form-group">
            <label>EPILEPSIA </label>
            <input type="radio" name="epilepsiaSim" id="epilepsiaSim" value="Sim"/>Sim
            <input type="radio" name="epilepsiaNao" id="epilepsiaNao" value="Nao"/>Não
            </div>

            <div class="form-group">
            <label>AVC </label>
            <input type="radio" name="avcSim" id="avcSim" value="Sim"/>Sim
            <input type="radio" name="avcNao" id="avcNao" value="Nao"/>Não
            <label>Histórico do AVC:</label>
            <input
              id="avcSim"
              placeholder="Digite o Histório do AVC"          
            />
            </div>

            <div class="form-group">
            <label>TABAGISMO</label>
            <input type="radio" name="tabagismoSim" id="tabagismoSim" value="Sim"/>Sim
            <input type="radio" name="tabagismoNao" id="tabagismoNao" value="Nao"/>Não
            <label>Histórico do TABAGISMO:</label>
            <input
              id="tabagismoSim"
              placeholder="Digite o Histório do TABAGISMO"          
            />
            </div>

            <div class="form-group">
            <label>ETILISMO</label>
            <input type="radio" name="etilismoSim" id="etilismoSim" value="Sim"/>Sim
            <input type="radio" name="etilismoNao" id="etilismoNao" value="Nao"/>Não
            <label>Histórico do ETILISMO:</label>
            <input
              id="etilismoSim"
              placeholder="Digite o Histório do ETILISMO"          
            />
            </div>

            <div class="form-group">
            <label>USO DE DROGAS</label>
            <input type="radio" name="uso_drogasSim" id="uso_drogasSim" value="Sim"/>Sim
            <input type="radio" name="uso_drogasNao" id="uso_drogasNao" value="Nao"/>Não
            <label>Histórico do USO DE DROGAS:</label>
            <input
              id="uso_drogasSim"
              placeholder="Digite o Histório do USO DE DROGAS"          
            />
            </div>

            <div class="form-group">
            <label>COAGULOPATIA</label>
            <input type="radio" name="coagulopatiaSim" id="coagulopatiaSim" value="Sim"/>Sim
            <input type="radio" name="coagulopatiaNao" id="coagulopatiaNao" value="Nao"/>Não
            <label>Histórico de COAGULOPATIA:</label>
            <input
              id="coagulopatiaSim"
              placeholder="Digite o Histório de COAGULOPATIA"          
            />
            </div>

            <div class="form-group">
            <label>PORTADOR DE NECESSIDADES ESPECIAIS</label>
            <input type="radio" name="pcdSim" id="pcdSim" value="Sim"/>Sim
            <input type="radio" name="pcdNao" id="pcdNao" value="Nao"/>Não
            <label>Informar o Tipo de Necessidades Especiais</label>
            <input
              id="pcdSim"
              placeholder="Digite o Tipo de Necessidades Especiais"          
            />
            </div>

            <div class="form-group">
            <label>INTERNAÇÕES NO ÚLTIMO ANO</label>
            <input type="radio" name="internacoes_ultimo_anoSim" id="internacoes_ultimo_anoSim" value="Sim"/>Sim
            <input type="radio" name="internacoes_ultimo_anoNao" id="internacoes_ultimo_anoNao" value="Nao"/>Não
            <label>Histórico de Internações do Último Ano</label>
            <input
              id="internacoes_ultimo_anoSim"
              placeholder="Digite Histórico de Internações do Último Ano"          
            />
            </div>

            <div class="form-group">
            <label>OUTROS</label>
            <input type="radio" name="outrosSim" id="outrosSim" value="Sim"/>Sim
            <input type="radio" name="outrosNao" id="outrosNao" value="Nao"/>Não
            <label>Histórico de OUTROS</label>
            <input
              id="outrosSim"
              placeholder="Digite Histórico de OUTROS"          
            />
            </div>


            
            <p>
            <br></br>
            <h2>CAPACIDADE FUNCIONAL</h2>
            <br></br>
            <br></br>
            </p>

            <div class="flex-container">
            <label>Medicações de Uso Contínuo</label>
            <input type="radio" name="medSim" id="medSim" value="Sim"/>Sim
            <input type="radio" name="medNao" id="medNao" value="Nao"/>Não
            <label>Histórico de Medicações de Usuo Contínuo</label>
            <input
              id="outrosSim"
              placeholder="Histórico de Medicações de Usuo Contínuo"          
            />
            </div>

            <div class="form-group">
            <label>História de Alergias</label>
            <input type="radio" name="alergiaSim" id="alergiaSim" value="Sim"/>Sim
            <input type="radio" name="alergiaNao" id="alergiaNao" value="Nao"/>Não
            <label>Histórico de Alergias</label>
            <input
              id="alergiaSim"
              placeholder="Histórico de Alergias"          
            />
            </div>


           

            <div class="form-group">
            <label>Passado Cirúrgico</label>
            <input type="radio" name="passadoCirurgicoSim" id="passadoCirurgicoSim" value="Sim"/>Sim
            <input type="radio" name="passadoCirurgicoNao" id="passadoCirurgicoNao" value="Nao"/>Não
            <label>Procedimentos Realizados</label>
            <input
              id="passadoCirurgicoSim"
              placeholder="Procedimentos Realizados"          
            />
            </div>

            <div class="form-group">
            <label>História Pessoal/Familiar de Evento Adverso Relacionado a Anestesia</label>
            <input type="radio" name="adversoSim" id="adversoSim" value="Sim"/>Sim
            <input type="radio" name="adversoNao" id="adversoNao" value="Nao"/>Não
            <label>Evento Adverso Relacionado a Anestesia</label>
            <input
              id="adversoSim"
              placeholder="Procedimentos Realizados"          
            />
            </div>

            <p>
            <br></br>
            <h2>EXAMES COMPLEMENTARES</h2>
            <br></br>
            <br></br>
            </p>

            <input
              id="Hb"
              placeholder="Informe o HB"          
            />

             <p>
            <br></br>
            <h2>EXAME FÍSICO
              
            </h2>
            <br></br>
            <br></br>
            </p>













            <button type="submit" className="btn">Enviar</button>
          </form>
        </div>
      </div>
    </Container>
  );
}
